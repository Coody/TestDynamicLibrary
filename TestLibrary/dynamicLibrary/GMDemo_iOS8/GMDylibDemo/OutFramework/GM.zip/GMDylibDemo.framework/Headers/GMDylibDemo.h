//
//  GMDylibDemo.h
//  GMDylibDemo
//
//  Created by WeiHan on 10/21/14.
//  Copyright (c) 2014 Wei Han. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for GMDylibDemo.
FOUNDATION_EXPORT double GMDylibDemoVersionNumber;

//! Project version string for GMDylibDemo.
FOUNDATION_EXPORT const unsigned char GMDylibDemoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GMDylibDemo/PublicHeader.h>

#import "GMDelegate.h"
#import "UIViewController+DelegateSetter.h"

